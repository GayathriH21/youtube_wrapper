# YouTube API Wrapper 

A Python package that wraps the YouTube Data API and YouTube Transcript API.

## Installation

```bash
pip install youtube_wrapper
